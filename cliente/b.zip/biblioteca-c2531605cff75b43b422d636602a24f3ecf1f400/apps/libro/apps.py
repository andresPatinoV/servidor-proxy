from django.apps import AppConfig


class LibroConfig(AppConfig):
    name = 'libro'
